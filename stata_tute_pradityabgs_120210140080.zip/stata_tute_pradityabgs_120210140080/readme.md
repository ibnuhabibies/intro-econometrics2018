Repo Praktikum Pengantar Etrik (ngulang wkwkw)
==============================================
Changelog:
8-3-2018	Adding census.dta, exporting data to xml, xls. saving do files